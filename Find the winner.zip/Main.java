import java.util.Scanner;
import java.util.*;

public class Main{
    
    public static void main(String[] args){
        
       Scanner sc=new Scanner(System.in);
       LinkedHashMap<Float,String> hm=new LinkedHashMap<Float,String>();
       System.out.println("Enter the number of teams");
int t = sc.nextInt();
if(t<=1){
System.out.println("Invalid input");
System.exit(0);
}
float min_sum =Float.MAX_VALUE;
int m= t;
float sum=0;
System.out.println("Enter the details");
for(int k=0;k<t;k++){
sum=0;
String str=sc.next();
String arr1[]= str.split(":");
int n =arr1.length;
float arr[]=new float[4];
arr[0]=Float.parseFloat(arr1[1]);
arr[1]=Float.parseFloat(arr1[2]);
arr[2]=Float.parseFloat(arr1[3]);
arr[3]=Float.parseFloat(arr1[4]);
if(arr[0]<1.0 || arr[1]<1.0 || arr[2]<1.0 || arr[3]<1.0){
System.out.println("Invalid number");
return;
}
sum = arr[0]+arr[1]+arr[2]+arr[3];
hm.put(sum,arr1[0]);
for(int i=0;i<t;i++){
if(sum<min_sum)
min_sum=sum;
}
}
String minKey= hm.get(min_sum);
if(minKey.equals("Prince")){
System.out.printf("King"+" team wins the race in %.2f minutes",min_sum);
}else{
System.out.printf(minKey+" team wins the race in %.2f minutes",min_sum);
}
        //Fill the code here
        
    }
}