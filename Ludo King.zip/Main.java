import java.util.Scanner;
public class Main 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here 
		System.out.println("Enter Alex points");
		int a=sc.nextInt();
		if(a<0 || a>50)
		    System.out.println(a+" is an invalid number");
		System.out.println("Enter Nikil points");
		int b=sc.nextInt();
		if(b<0 || b>50)
		    System.out.println(b+" is an invalid number");
		System.out.println("Enter Sam points");
		int c=sc.nextInt();
		if(c<0 || c>50)
		    System.out.println(c+" is an invalid number");
        if(a>b && a>c)
            System.out.println("Alex scored "+a+" points and won the game");
        else if(b>a && b>c)
            System.out.println("Nikil scored "+b+" points and won the game");
        else
            System.out.println("Sam scored "+c+" points and won the game");

	}
}