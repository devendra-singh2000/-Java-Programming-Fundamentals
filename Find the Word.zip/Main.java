import java.util.Scanner;
public class Main 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here 
		System.out.println("Enter the alphabet");
		char input=sc.next().charAt(0);
		if(input=='A')
		    System.out.println("A for apple");
		else if(input=='B')
		    System.out.println("B for Ball");
		else if(input=='C')
		    System.out.println("C for Cat");
		else if(input=='D')
		    System.out.println("D for Dog");
		else if(input=='E')
		    System.out.println("E for Elephant");
		else
		    System.out.println(input+ " is an invalid input");
		 
	}
}