import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Stream;
import java.util.List;
public class ManagementUtility {

    public List<Donor> getDonorDetails(String[] details) {
        // Fill the code here
        List<Donor> temp = new ArrayList<Donor>();
        for(int i=0;i<details.length;i++){
            String newTemp = details[i];
            String[] splitString = newTemp.split(":");
            long mb = Long.parseLong(splitString[3]);
            temp.add(new Donor(splitString[0],splitString[1],splitString[2],mb));
        }
        return temp;
    }

    public Stream<Donor> getStreamOfDonor(List<Donor> donorDetails) {
        // Fill the code here

        return donorDetails.stream();
    }

    public List<String> shortlistedDonor(Stream<Donor> donorStream, String bloodGroup) {
        List<String> result = new ArrayList<String>();
        // Fill the code here
        donorStream.filter(s-> s.getBloodGroup().equals(bloodGroup)).forEach(s -> {result.add(s.getDonorName());});
           Collections.sort(result);
        return result;
    }

}
