public class Donor {
    String donorId;
    String donorName;
    String bloodGroup;
    long mobileNumber;

    public Donor(String id,String name,String group,long mn){
        this.donorId = id;
        this.donorName = name;
        this.bloodGroup = group;
        this.mobileNumber = mn;
    }
    public long getMobileNumber() {
        return mobileNumber;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public String getDonorId() {
        return donorId;
    }

    public String getDonorName() {
        return donorName;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public void setDonorId(String donorId) {
        this.donorId = donorId;
    }

    public void setDonorName(String donorName) {
        this.donorName = donorName;
    }

    public void setMobileNumber(long mobileNumber) {
        this.mobileNumber = mobileNumber;
    }
}
