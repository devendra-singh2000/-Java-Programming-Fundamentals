import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

class Main{
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      ManagementUtility mu = new ManagementUtility();
      System.out.println("Enter the number of donors");
      int n = Integer.parseInt(sc.nextLine());
      System.out.println("Enter the donor details");
      String[] Strings = new String[n];
      for(int i=0;i<n;i++){
          String donor = sc.nextLine();
          Strings[i] = donor;

      }
      List<Donor> res = mu.getDonorDetails(Strings);
      Stream<Donor> result = mu.getStreamOfDonor(res);
      System.out.println("Enter the blood group to search");
      String bloodGroup = sc.nextLine();
      List<String> finalResult = mu.shortlistedDonor(result,bloodGroup);
      if(finalResult.size() != 0) {
          System.out.println("List of shortlisted donors");
          finalResult.forEach(s -> {
              System.out.println(s);
          });
      }else{
          System.out.println("No donor found");
      }
    }
}
