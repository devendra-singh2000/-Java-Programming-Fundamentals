import java.util.*;

public class Main{
    
    static String sortString(String str) {
char []arr = str.toCharArray();
Arrays.sort(arr);
return String.valueOf(arr);
}
public static void main(String[] args){
    Scanner sc=new Scanner(System.in);
System.out.println("Enter the sentence");
String str= sc.nextLine();
String arr1[]= str.split(" ");
int n =arr1.length;
for(int j=0;j<n;j++){
char[] chars = arr1[j].toCharArray();
for(char c : chars){
if(Character.isDigit(c)){
System.out.print(str+" is an invalid input");
return;
}
}
}
String arr[]=new String[n];
for(int i=0;i<n;i++){
arr[i]=sortString(arr1[i]);
System.out.print(arr[i]+" ");
}
}
}