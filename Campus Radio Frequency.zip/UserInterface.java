import java.util.Scanner;
public class UserInterface {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
System.out.println("Scan the radio station");
float freq = sc.nextFloat();
try{
Validator vd=new Validator();
vd.validateStation(freq);
System.out.println("Radio Station on!");
}catch(StationNotAvailableException e){
System.out.println("Radio Station not available");
}
// fill in the code
}
}