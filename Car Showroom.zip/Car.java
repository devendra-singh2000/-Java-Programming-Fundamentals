public class Car {
    private String carId;
    private String modelNumber;
    private String colour;
    private String transmissionType;
    private String fuelType;
    private String engineType;
    private String bodyType;
    private int engineDisplacement;
    private int bootSpace;
    private int seatCapacity;
    public Car(String carId,String modelNumber,String colour,String transmissionType,String fuelType,String engineType,String bodyType,int engineDisplacement,int bootSpace,int seatCapacity){
        this.carId=carId;
        this.modelNumber=modelNumber;
        this.colour=colour;
        this.transmissionType=transmissionType;
        this.fuelType=fuelType;
        this.engineType=engineType;
        this.bodyType=bodyType;
        this.engineDisplacement=engineDisplacement;
        this.bootSpace=bootSpace;
        this.seatCapacity= seatCapacity;
    }
public String getCarId()
{
return this.carId;
}
public void setCarId(String carId)
{
this.carId=carId;
}
public String getModelNumber()
{
return this.modelNumber;
}
public void setModelNumber(String modelNumber)
{
this.modelNumber=modelNumber;
}
public String getColour()
{
return this.colour;
}
public void setColour(String colour)
{
this.colour=colour;
}
public String getTransmissionType()
{
return this.transmissionType;
}
public void setTransmissionType(String transmissionType)
{
this.transmissionType=transmissionType;
}
public String getFuelType()
{
return this.fuelType;
}
public void setFuelType(String fuelType)
{
this.fuelType=fuelType;
}
public String getEngineType()
{
return this.engineType;
}
public void setEngineType(String engineType)
{
this.engineType=engineType;
}
public String getBodyType()
{
return this.bodyType;
}
public void setBodyType(String bodyType)
{
this.bodyType=bodyType;
}
public int getEngineDisplacement()
{
return this.engineDisplacement;
}
public void setEngineDisplacement(int engineDisplacement)
{
this.engineDisplacement=engineDisplacement;
}
public int getBootSpace()
{
return this.bootSpace;
}
public void setBootSpace(int bootSpace)
{
this.bootSpace=bootSpace;
}
public int getSeatCapacity()
{
return this.seatCapacity;
}
public void setSeatCapacity(int seatCapacity)
{
this.seatCapacity= seatCapacity;
} // Fill the code
}