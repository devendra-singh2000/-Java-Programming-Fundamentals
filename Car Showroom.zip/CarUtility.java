import java.util.Scanner;
public class CarUtility {
public static void main(String[] args) {
Car[] car=createCarDetails();
System.out.println("No of Car Details "+car.length);
for(int i=0;i<car.length;i++)
{
System.out.println("Car Details "+(i+1));
System.out.println("Car Id "+car[i].getCarId());
System.out.println("Model Number "+car[i].getModelNumber());
System.out.println("Colour "+car[i].getColour());
System.out.println("Transmission Type "+car[i].getTransmissionType());
String fueltype=car[i].getFuelType();
fueltype=fueltype.substring(0,1).toUpperCase()+fueltype.substring(1);
System.out.println("Fuel Type "+fueltype);
String enginetype=car[i].getEngineType();
enginetype=enginetype.substring(0,1)+enginetype.substring(1).toLowerCase();
System.out.println("Engine Type "+enginetype);
String bodytype=car[i].getBodyType();
bodytype=bodytype.substring(0,1).toUpperCase()+bodytype.substring(1);
System.out.println("Body Type "+bodytype);
System.out.println("Engine Displacement "+car[i].getEngineDisplacement());
System.out.println("Boot Space "+car[i].getBootSpace());
System.out.println("Seat Capacity "+car[i].getSeatCapacity());
}
}
public static Car[] createCarDetails(){
Scanner sc = new Scanner(System.in);
System.out.println("Enter the number of car details to created ");
int N=sc.nextInt();
Car car[]=new Car[N];
for(int i=0;i<N;i++)
{
System.out.println("Enter Car Id");
String carId=sc.next();
System.out.println("Enter Model Number");
String modelNumber=sc.next();
System.out.println("Enter Colour");
String colour=sc.next();
System.out.println("Enter Transmission Type");
String transmissionType=sc.next();
System.out.println("Enter Fuel Type");
String fuelType=sc.next();
System.out.println("Enter Engine Type");
String engineType=sc.next();
System.out.println("Enter Body Type");
String bodyType=sc.next();
System.out.println("Enter Engine Displacement");
int engineDisplacement=sc.nextInt();
System.out.println("Enter Boot Space");
int bootSpace=sc.nextInt();
System.out.println("Enter Seat Capacity");
int seatCapacity = sc.nextInt();
car[i]=new
Car(carId,modelNumber,colour,transmissionType,fuelType,engineType,bodyType,engineDisplacement,bootSpace,seatCapacity);
} return car;
}
}