import java.util.List;
import java.util.stream.Stream;
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Function;
public class ManagementUtility {
	private List<VegetableBasket> vegetableBasketList = new ArrayList<VegetableBasket>();;
		
	public List<VegetableBasket> getVegetableBasketList() {
		return this.vegetableBasketList;
	}

	public void setVegetableBasketList(List<VegetableBasket> vegetableBasketList) {
		this.vegetableBasketList = vegetableBasketList;
	}

	public void addToBasket(VegetableBasket fbObj) {
		List<VegetableBasket> vge= getVegetableBasketList();
		vge.add(fbObj);
		setVegetableBasketList(vge);
		//Fill the code here
	}
	
	public static int calculateBill(Stream<VegetableBasket> vegetableBasketStream) {
	Map<Integer, Integer> V = vegetableBasketStream.collect(Collectors.toMap(VegetableBasket-> VegetableBasket.getWeightInKgs(),VegetableBasket -> VegetableBasket.getPricePerKg()));
    int amount=0;
    for(Map.Entry<Integer, Integer>entry : V.entrySet()) {
    amount=amount+(entry.getKey()*entry.getValue());
        
    }
    return amount;
	}

}
