import java.util.Scanner;
import java.util.stream.Stream;
import java.util.*;
public class Main {

	public static void main(String[] args) {
	    
		Scanner sc = new Scanner(System.in);
		int num = 0;

		ManagementUtility m=new ManagementUtility();
		while(num != 3){
		System.out.println("Select an option:\n1.Add Vegetable to Basket\n2.Calculate Bill\n3.Exit");
		num = sc.nextInt();
		if(num == 1){
		    VegetableBasket vege=new VegetableBasket();
		    System.out.println("Enter the vegetable name");
		    String name=sc.next();
		    System.out.println("Enter weight in Kgs");
		    int weight = sc.nextInt();
		    System.out.println("Enter price per Kg");
		    int price = sc.nextInt();
		    vege.setVegetableName(name);
		    vege.setWeightInKgs(weight);
		    vege.setPricePerKg(price);
		    m.addToBasket(vege);
		    }
		    else if(num==2)
		    {
		        List<VegetableBasket>vegeBasketList =m.getVegetableBasketList();
		        if(vegeBasketList.size()==0)
		        {
		            System.out.println("Customer basket is empty. Please add vegetables.");
		        }
		        else{
		            Stream<VegetableBasket>vegetableBasketStream = vegeBasketList.stream();
		        int amount = m.calculateBill(vegetableBasketStream);
		       System.out.println("The estimated bill amount is Rs "+amount);
		        }
		        
		    }
		}
		System.out.println("Thank you for using the application.");
		
	}

}
