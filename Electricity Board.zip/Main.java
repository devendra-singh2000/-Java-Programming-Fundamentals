import java.util.*;
public class Main {
public static void main(String[] args) {
Scanner scanner=new Scanner(System.in);
System.out.println("Enter Customer Id");
String str= scanner.nextLine();
System.out.println("Enter Customer Name");
String s2 = scanner.nextLine();
System.out.println("Enter Phone Number");
long phone = scanner.nextLong();
System.out.println("Enter City");
String city = scanner.next();
System.out.println("Enter Units Consumed");
double cu=scanner.nextDouble();
System.out.println("Enter Cost per Unit");
double cuu=scanner.nextDouble();
CustomerDetails c1= new CustomerDetails(str,s2,phone,city,cu,cuu);
System.out.println("Amount to be paid is Rs."+
String.format("%.2f",c1.calculateElectricityBill()));
}
}