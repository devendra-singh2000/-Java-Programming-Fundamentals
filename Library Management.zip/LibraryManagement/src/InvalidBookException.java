public class InvalidBookException extends Exception{
//FILL THE CODE
String s;
public InvalidBookException (String s){
super(s);
}}
