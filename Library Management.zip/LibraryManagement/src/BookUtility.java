import java.util.ArrayList;
import java.util.List;public class BookUtility implements Runnable{
private List<Book> bookList = new ArrayList<Book>();
private String searchbookName;
private int counter;
//FILL THE CODE HERE
public List<Book> getBookList(){
return bookList;
}
public String getSearchbookName(){
return searchbookName;
}
public void setBookList(List<Book> a){
this.bookList=a;
}
public void setSearchbookName(String x){
this.searchbookName=x;
}
public int getCounter(){
return counter;
}
public void setCounter(int counter){
this.counter=counter;
}
public void toValidateBookType(Book obj) throws InvalidBookException
{
//FILL THE CODE
if (obj.getBookType().compareToIgnoreCase("Engineering")==0){
bookList.add(obj);
}else{
throw new InvalidBookException("Book type Invalid");
}
}
public void run()
{
//FILL THE CODE HERE
int count=0;
for(int j=0;j<bookList.size();j++){
if (bookList.get(j).getBookName().compareToIgnoreCase(searchbookName)==0){
count=count+1;
}
}
if (count==0) {
System.out.println("No Books found");
}else {
System.out.println("Count of books in the library with the book name "+searchbookName.toUpperCase()+" is "+count);
}}}

