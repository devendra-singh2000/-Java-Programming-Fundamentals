import java.util.Scanner;



public class UserInterface {



public static void main(String[] args) {

Scanner s = new Scanner(System.in);
// Fill the code

System.out.println("Enter Student Id");
int studentId = s.nextInt();
System.out.println("Enter Student name");
String studentName = s.next();
System.out.println("Enter Department name");
String department = s.next();
System.out.println("Enter gender");
String gender = s.next();
System.out.println("Enter category");
String category = s.next();
System.out.println("Enter College fee");
double collegeFee = s.nextDouble();



switch(category){
case "DayScholar":
System.out.println("Enter Bus number");
int busNumber = s.nextInt();
System.out.println("Enter the distance");
float distance = s.nextFloat();



DayScholar dayScholar = new DayScholar(
studentId,
studentName,
department,
gender,
category,
collegeFee,
busNumber,
distance
);



System.out.println("Total College fee is "+dayScholar.calculateTotalFee());
break;



case "Hosteller":
System.out.println("Enter the room number");
int roomNumber = s.nextInt();
System.out.println("Enter the Block name");
char blockName = s.next().charAt(0);
System.out.println("Enter the room type");
String roomType = s.next();



Hosteller hosteller = new Hosteller(
studentId,
studentName,
department,
gender,
category,
collegeFee,
roomNumber,
blockName,
roomType
);



System.out.println("Total College fee is "+hosteller.calculateTotalFee());
break;
}
}



}
