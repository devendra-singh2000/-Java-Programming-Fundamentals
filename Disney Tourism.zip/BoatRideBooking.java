public class BoatRideBooking extends Booking{

// Fill the code

private float noOfHours;
private String guide;



public BoatRideBooking(String customerName, String cityName, String phoneNumber, int noOfPeople, float noOfHours, String guide) {
super(customerName, cityName, phoneNumber, noOfPeople);
this.noOfHours=noOfHours;
this.guide=guide;
}


public double calculateTotalAmount() {
// Fill the code

if(this.guide.equals("Yes") || this.guide.equals("yes")){
return (double)(this.noOfPeople*80) + (this.noOfHours*300) + 150;
}else if(this.guide.equals("No") || this.guide.equals("no")){
return (double)(this.noOfPeople*80) + (this.noOfHours*300);
}
return 0.0;
}

}
