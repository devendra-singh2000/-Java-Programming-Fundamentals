import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		// Fill the code
           System.out.println("Enter the Customer Name");
           String custName = s.next();
           System.out.println("Enter the City name");
           String cityName = s.next();
           System.out.println("Enter the phone number");
           String phoneNumber = s.next();
           System.out.println("Enter number of people");
           int numPeople=s.nextInt();
           System.out.println("Enter the option");
           System.out.println("1. Boat House Booking");
           System.out.println("2. Boat Ride Booking");
           int option = s.nextInt();
           switch(option){
           case 1:
                System.out.println("Enter number of days");
                int numberOfDays = s.nextInt();
                System.out.println("Enter food type (Veg/NonVeg)");
                String foodType=s.next();
                BoatHouseBooking bhb=new BoatHouseBooking(custName,cityName,phoneNumber,numPeople,numberOfDays,foodType);
                System.out.println("Your booking has been confirmed pay Rs."+bhb.calculateTotalAmount());
                break;

           case 2:
                System.out.println("Enter number of hours");
                float numberOfHours = s.nextFloat();
                System.out.println("Do you want guide (Yes/No)");
                String guide=s.next();
                BoatRideBooking brb=new BoatRideBooking(custName,cityName,phoneNumber,numPeople,numberOfHours,guide);
                System.out.println("Your booking has been confirmed pay Rs."+brb.calculateTotalAmount());
                break;

        }
	}

}
