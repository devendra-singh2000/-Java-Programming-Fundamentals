public class BoatHouseBooking extends Booking{

// Fill the code

private int noOfDays;
private String foodType;

public int getNoOfDays() {
return noOfDays;
}

public void setNoOfDays(int noOfDays) {
this.noOfDays = noOfDays;
}

public String getFoodType() {
return foodType;
}

public void setFoodType(String foodType) {
this.foodType = foodType;
}

public BoatHouseBooking(String customerName, String cityName, String phoneNumber, int noOfPeople, int noOfDays,String foodType) {
super(customerName, cityName, phoneNumber, noOfPeople);
this.noOfDays=noOfDays;
this.foodType=foodType;
}

public double calculateTotalAmount() {

// Fill the code

if(this.foodType.equals("NonVeg")){
return (double)(this.noOfPeople*800) + (this.noOfDays*3000)+500;
}else if(this.foodType.equals("Veg") || this.foodType.equals("VEG")){
return (double)((this.noOfPeople*800) + (this.noOfDays*3000)+250);
}

return 0.0;
}


}
