import java.util.Scanner;
import java.util.stream.Stream;
public class Main{
    
    public static void main(String[] args){
        
       Scanner sc=new Scanner(System.in);
       
        //Fill the code here
        String st = sc.nextLine();
		String[] arr =st.split(":");
		int ad=Integer.parseInt(String.valueOf(arr[1]));
		int ch=Integer.parseInt(String.valueOf(arr[2]));
		int days=Integer.parseInt(String.valueOf(arr[3]));
        if(ad<0)
            System.out.println("Invalid input for number of adults");
        if(ch<0)
            System.out.println("Invalid input for number of children");
        if(days<=0)
            System.out.println("Invalid input for number of days");
	
        int cost=(ad*days*1000)+(ch*days*650);
        System.out.println(arr[0]+" your booking is confirmed and the total cost is Rs "+cost);
    }
}