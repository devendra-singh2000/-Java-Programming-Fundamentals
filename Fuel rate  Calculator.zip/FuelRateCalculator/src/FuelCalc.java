@FunctionalInterface
public interface FuelCalc {
	public double calculateFuel(String fuelName,double litres);
}
