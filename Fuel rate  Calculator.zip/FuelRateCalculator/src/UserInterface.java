import java.util.*;
public class UserInterface {
	public static FuelCalc generateRate()
	{
		 return (String fuelName, double litres)->
		{   double price=0;
		    fuelName=fuelName.toLowerCase();
		    if(fuelName.equals("petrol"))  
		     price=litres*90.4;
		    else if(fuelName.equals("diesel"))
		    price=litres*86.8;
		    return price;
		};
	}
	public static void main(String [] args)
	{ 
	    Scanner sc=new Scanner(System.in);
		System.out.println("Enter the type of fuel");
		String s=sc.next();
		System.out.println("Enter litres");
		double l=sc.nextDouble();
		FuelCalc f=generateRate();
		double p=f.calculateFuel(s,l);
		
		System.out.printf("Total Cost of the fuel =Rs. %.2f",p);
	}

}
