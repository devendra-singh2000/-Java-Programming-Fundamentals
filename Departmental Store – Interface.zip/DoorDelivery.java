public interface DoorDelivery {
	
	// Fill the code
	public abstract double deliveryCharge();
}

