public interface BonusPoints {
	
	// Fill the code
	public abstract double calculateBonusPoints();
	
}

