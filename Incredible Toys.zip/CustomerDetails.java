import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class CustomerDetails {
private String customerId;
private String customerName;
private long phoneNumber;
private String emailId;
private String toyType;
private double price;
public CustomerDetails(String customerId,String customerName,long phoneNumber,String
emailId, String toyType,double price)
{
this.customerId=customerId;
this.customerName=customerName;
this.phoneNumber=phoneNumber;
this.emailId=emailId;
this.toyType=toyType;
this.price=price;
}
public String getCustomerId()
{
return this.customerId;
}
public void setCustomerId(String customerId)
{
this.customerId=customerId;
}
public String getCustomerName()
{
return this.customerName;
}
public void setCustomerName(String customerName)
{
this.customerName=customerName;
}
public long getPhoneNumber()
{
return this.phoneNumber;
}
public void setPhoneNumber(long phoneNumber)
{
this.phoneNumber=phoneNumber;
}
public String getEmailId()
{
return this.emailId;
}
public void setEmailId(String emailId)
{
this.emailId=emailId;
}
public String getToyType()
{
return toyType;
}
public void setToyType(String toyType)
{
this.toyType=toyType;
}
public double getPrice()
{
return this.price;
}
public void setPrice(double price)
{
this.price=price;
}
// Fill the code
public boolean validateCustomerId() {
String customerId=getCustomerId();
String pattern = "Incredible/[0-9]{3}/[0-9]{4}";
Pattern r = Pattern.compile(pattern);
Matcher m = r.matcher(customerId);
if(m.find())
{
return true;
}
return false;
}
public double calculateDiscount() {
double price = getPrice();
int dis=0;
toyType=toyType.toLowerCase();
switch(toyType)
{
case "softtoys":
dis=5;
break;
case "fidgettoys":
dis=10;
break;
case "sensorytoys":
dis=15;
break;
case "puzzles":
dis=20;
break;
}
return (price-(price*dis/100));
}
}
