import java.util.Scanner;
public class Main {
public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.println("Enter Customer Id");
String customerId=sc.next();
System.out.println("Enter Customer Name");
String customerName=sc.next();
System.out.println("Enter Phone Number");
long phoneNumber=sc.nextLong();
System.out.println("Enter Email Id");
String emailId=sc.next();
System.out.println("Enter type");
String toyType=sc.next();
System.out.println("Enter Price");
double price = Double.parseDouble(sc.next());
CustomerDetails cd=new
CustomerDetails(customerId,customerName,phoneNumber,emailId,toyType,price);
if(cd.validateCustomerId())
{
double amount=cd.calculateDiscount();
System.out.printf("Amount to be paid by the Customer %.2f",amount);
}
else{
System.out.println("Provide a proper Customer Id");
}
}
}
