import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner;

public class Main 
{

	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int flag=1;
	    try {
	        File myObj = new File("customer.txt");
	        Scanner myReader = new Scanner(myObj);
	        String data = myReader.nextLine();
	        System.out.println("Enter the mobile number");
	        String Value = sc.next();

            while (myReader.hasNextLine()){ 
                final String lineFromFile = myReader.nextLine();
                if(lineFromFile.contains(Value)){
                    // System.out.println("customer.txt");
                    System.out.println(lineFromFile);
                    flag=0;
                    break;
                }
               
            }
            if (flag==1)
            {
                System.out.println("No customer found");
            }
            myReader.close();
	        
	    }
	    catch (FileNotFoundException e) {
	        System.out.println("An error occurred.");
	        e.printStackTrace();
	        
	    }
	    
	}
}
