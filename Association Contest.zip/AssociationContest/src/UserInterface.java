import java.util.*;
import java.util.stream.Stream;
public class UserInterface {

	public static void main(String[] args) 
	{
	    Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of contestant details to enter:");
		int N=sc.nextInt();
		if(N>0)
		{
		System.out.println("Enter the contestant details:");
		List<Contestant> ContestList = new ArrayList<Contestant>();
		ContestUtility C = new ContestUtility();
		for(int i=0;i<N;i++)
		{
		    String arr=sc.next();
		    String[] word=arr.split("/");
		    String id=word[0];
		    String name = word[1];
		    String place=word[2];
		    Contestant c=new Contestant();
		    c.setId(id);
		    c.setName(name);
		    c.setAddress(place);
		    ContestList.add(c);
		    
		 }
        C.setContestList(ContestList);
        Stream<Contestant>stream = C.changeToStream();
        System.out.println("Enter character to search");
        char alpha = sc.next().charAt(0);
        List list=C.searchFromDetails(stream,alpha);
		List<Contestant> Contest = C.getContestList();
		if(list.size()!=0)
		{
		    System.out.println("Filter the names which starts with "+alpha+":");
		    for(int i=0;i<N;i++)
		    {
		        if(list.contains(Contest.get(i).getId()))
		        {
		        System.out.println("Id: "+Contest.get(i).getId()+", Name: "+Contest.get(i).getName());
		        }
		    }
		}
		else{
		    System.out.println("No record found");
		}
		
		
		
		}
		else{
		    System.out.println("Invalid");
		}
	}

}
