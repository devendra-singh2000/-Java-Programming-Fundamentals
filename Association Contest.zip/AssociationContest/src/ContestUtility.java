import java.util.List;
import java.util.Map;
import java.util.*;
import java.util.stream.Stream;
import java.util.stream.Collectors;
public class ContestUtility {
	private List<Contestant> ContestList;

	public List<Contestant> getContestList(){
	    return this.ContestList;
	}
    public void setContestList(List<Contestant> ContestList)
    {
        this.ContestList=ContestList;
    }
	public Stream<Contestant> changeToStream() {
		List<Contestant> list = getContestList();
		 
		return list.stream();
	}

	public List searchFromDetails(Stream<Contestant> stream1,char varString) {
		Map<String,String>file = stream1.collect(Collectors.toMap(Contestant->Contestant.getId(),Contestant->Contestant.getName()));
		List<String> l = new ArrayList<String>();
		for (Map.Entry<String,String> entry : file.entrySet())
		{
		    String s=Character.toString(varString);
		    if(entry.getValue().toLowerCase().startsWith(s.toLowerCase()))
		    {
		        l.add(entry.getKey());
		    }
		    
		}
           
		return l;
		
	}
	
}
