import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Doctor doc=createDoctorDetails();
		System.out.println("Doctor id:"+doc.getDoctorId());
		System.out.println("Doctor name:"+doc.getDoctorName());
		System.out.println("Specialization:"+doc.getSpecialization());
		System.out.println("Hospital name:"+doc.getHospital().getHospitalName());
		System.out.println("Contact Number:"+doc.getHospital().getContactNumber());
		System.out.println("City:"+doc.getHospital().getCity());
	}
	public static Doctor createDoctorDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Hospital Name");
		String hName=sc.nextLine();
		System.out.println("Enter Contact Number");
		long cNo=sc.nextLong();
		sc.nextLine();
		System.out.println("Enter City");
		String city=sc.nextLine();
		Hospital h=new Hospital(hName,cNo,city);
		System.out.println("Enter Doctor Id");
		String id=sc.nextLine();
		System.out.println("Enter Doctor Name");
		String dName=sc.nextLine();
		System.out.println("Enter Specialization");
		String specialization = sc.nextLine();
		Doctor doc=new Doctor(id,dName,specialization,h);
		return doc;
	}
}
