import java.util.List;
import java.util.stream.Stream;
import java.util.stream.Collectors;
public class BookUtility {
private List<Book> bookList; //FILL THE CODE HERE
public List<Book> getBookList(){
return bookList;
}
public void setBookList(List<Book> a){
this.bookList=a;
} public Stream<Book> listToStream() {
//FILL THE CODE HERE
Stream<Book> ab = bookList.stream();
return ab;
} public List <Double> calculateBookDiscount(Stream<Book> stream1) {
//FILL THE CODE HERE
List <Double> ans = stream1.map(x->x.getBookCost()-((x.getBookCost()*10)/100)).collect(Collectors.toList());
return ans;
}}
