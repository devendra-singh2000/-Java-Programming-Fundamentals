import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;public class UserInterface {
public static void main(String [] args)
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter the number of books");
int a = Integer.parseInt(sc.nextLine());
if (a<=0){
System.out.println("Invalid Entry");
}else{
List<Book> ob = new ArrayList<Book>();
String[] x = new String[a];
System.out.println("Enter book details");
for (int j=0;j<a;j++){
x[j] =sc.nextLine();
String[] p = x[j].split(":");
Book on = new Book();
on.setBookName(p[0]);
on.setAuthorName(p[1]);
on.setBookCost(Double.parseDouble(p[2]));
ob.add(on);
}
BookUtility xo = new BookUtility();
xo.setBookList(ob);
List <Double> ab=xo.calculateBookDiscount(xo.listToStream());
System.out.println("Updated Book Cost:");
for (int i = 0; i < ab.size(); i++) {
// Print all elements of List
System.out.println(ab.get(i));
}
}
}}
