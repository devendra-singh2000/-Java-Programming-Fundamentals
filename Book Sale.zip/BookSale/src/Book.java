// DO NOT EDIT OR ADD ANY CODE
public class Book {
	private String bookName;
	private String authorName;
	private double bookCost;
	
	//Setters and Getters
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public double getBookCost() {
		return bookCost;
	}
	public void setBookCost(double bookCost) {
		this.bookCost = bookCost;
	}
	@Override
	public String toString() {
		return "Book [bookName=" + bookName + ", authorName=" + authorName + ", bookCost=" + bookCost + "]";
	}
	
	
	
	
}
