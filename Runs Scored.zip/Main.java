import java.util.Scanner;
public class Main 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here 
		System.out.println("Runs scored");  
		int runs= sc.nextInt();
		System.out.println("Boundaries scored");  
		int b= sc.nextInt();
		System.out.println("Sixers scored");  
		int s= sc.nextInt();
		int rs=runs-((b*4)+(s*6));
		float per = (runs - rs)*100/ runs;
		System.out.println("Runs scored running between wickets "+rs);
		System.out.print("Percentage of runs scored running between wickets ");
		System.out.printf("%.2f",per);
		
	}
}