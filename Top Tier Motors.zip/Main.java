import java.util.*;

public class Main {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of vehicles");
        int n = Integer.parseInt(sc.nextLine());
        VehicleUtility vh = new VehicleUtility();
		vh.setVehicleMap(new HashMap<String,Double>());
		for(int i=0;i<n;i++){
		    System.out.println("Enter the vehicle name and price of Vehicle "+(i+1));
		    String veh=sc.nextLine();
		    double price=Double.parseDouble(sc.nextLine());
		    vh.addVehiclePriceDetails(veh,price);
		    
		}
		Map<String,Double> polmap=vh.getVehicleMap();
        char choice;
        do
        {
            System.out.println("Enter the vehicle name to be searched");
            String search = sc.nextLine();
            if(vh.calculateCostAfterDiscount(search)!=0){
                System.out.println("Price after discount for "+ search +" is "+vh.calculateCostAfterDiscount(search));
                
            }
            else{
                System.out.println( "TVS Apache RTR 180 is not available currently");
                
            }
            System.out.println("Do you want to continue (Y/N)");
            choice=sc.nextLine().charAt(0);
            if((choice=='n')||(choice=='N')){
                System.out.println("Thank you for using the Application");
                break;
                
            }
            
        }
        while((choice=='y')||(choice=='Y'));
        
    }
    
}
