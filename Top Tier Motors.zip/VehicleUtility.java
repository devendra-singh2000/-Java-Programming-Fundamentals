import java.util.HashMap;
import java.util.Map;

public class VehicleUtility {
    private Map<String, Double> vehicleMap = new HashMap<String, Double>();
    public Map<String, Double> getVehicleMap() {
        return vehicleMap;
        
    }
    public void setVehicleMap(Map<String, Double> vehicleMap) {
        this.vehicleMap = vehicleMap;
        
    }
    // This method should add the vehicleName as key and the price of the
	// vehicle as value into a Map
	public void addVehiclePriceDetails(String vehicleName, double price) {
		// fill the code
		vehicleMap.put(vehicleName,price);
	    
	}

	// This method should calculate the discount and return the selling price
	// after the discount for the vehicle name passed as an argument.
	public double calculateCostAfterDiscount(String vehicleName) {
	    if(vehicleMap.containsKey(vehicleName)){
	        double discount=0;
	        double sp=0;
	        double h=vehicleMap.get(vehicleName);
	        if(vehicleName.contains("TVS")){
	            discount=10;
	            
	        }
	        else if(vehicleName.contains("Honda")){
	            discount=5;
	            
	        }
	        else if(vehicleName.contains("Yamaha")){
	            discount=7;
	            
	        }
	        sp= h*(100-discount)/100;
	        return sp;
	        
	    }
	    else{
	        return 0;
        }
	}
}
