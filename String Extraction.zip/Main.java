import java.util.Scanner;

public class Main {
	
	public static void main(String args[])
    {
       Scanner sc = new Scanner(System.in);
        System.out.println("Enter the String");
        String str1 = sc.nextLine();
        System.out.println("Enter First Index");
        int start = sc.nextInt();
        System.out.println("Enter Second Index");
        int end = sc.nextInt();
        Main s = new Main();
        String str2 = s.extractString(str1,start,end);
        System.out.println(str2);
       //System.out.println(s);
    }
	
	public String extractString(String sentence,int number1,int number2)
    {
        // Fill the code
        try {
            return (sentence.substring(number1, number2)+".Thanks for using the application.");
        }catch(StringIndexOutOfBoundsException e){
            return ("Extraction of String using the given index is not possible.Thanks for using the application.");
        }
    }

}