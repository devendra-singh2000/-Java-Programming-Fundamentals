import java.util.Scanner;

public class GameCardDetails {

    public CardPoints getCardDetails()
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter card id");
        int cardId = sc.nextInt();

        System.out.println("Enter card holder name");
        String holderName = sc.next();
        System.out.println("Enter balance points");
        int balancePoints = sc.nextInt();
        do{
        if (balancePoints <= 0){
            System.out.println("Balance points should be positive");
            System.out.println("Enter balance points");
            balancePoints = sc.nextInt();
            continue;
        }
        else
        {
            break;
        }
        }
        while(true);

        return new CardPoints(cardId, holderName, balancePoints);
    }
    public int getPointUsage()
    {
        Scanner sc = new Scanner(System.in);

        int pointUsage = sc.nextInt();
        if (pointUsage <= 0){
            System.out.println("Points should be positive");
            return getPointUsage();
        }
        return pointUsage;
    }

    public static void main(String[] arg)
    {
        GameCardDetails gameCardDetails = new GameCardDetails();
        CardPoints cp = gameCardDetails.getCardDetails();
        System.out.println("Enter points should be used");
        int points = gameCardDetails.getPointUsage();
        cp.withdrawPoints(points);

    }
}