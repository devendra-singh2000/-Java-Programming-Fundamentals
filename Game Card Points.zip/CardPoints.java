public class CardPoints {


    private int cardId;
    private String holderName;
    private int balancePoints;

    public CardPoints(int cardId, String holderName, int balancePoints) {
        this.cardId = cardId;
        this.holderName = holderName;
        this.balancePoints = balancePoints;
    }

    public boolean withdrawPoints(int points) {
        if(balancePoints >= points) {
            balancePoints -= points;
            System.out.println("Balance points after used:" + balancePoints);
            return true;
        } else {
            System.out.println("Sorry!!! No enough points");
            return false;
        }
    }

    public int getCardId() {
        return cardId;
    }

    public void setCardId(int cardId) {
        this.cardId = cardId;
    }

    public String getHolderName() {
        return holderName;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public int getBalancePoints() {
        return balancePoints;
    }

    public void setBalancePoints(int balancePoints) {
        this.balancePoints = balancePoints;
    }
}


