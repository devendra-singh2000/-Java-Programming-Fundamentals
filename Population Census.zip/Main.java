import java.util.Scanner;
public class Main 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here 
		System.out.println(" Enter population before 10 years");  
		int b= sc.nextInt();
		System.out.println("Enter population after 10 years");  
		int a= sc.nextInt();
		
		System.out.println("Population before 10 years "+b);
		System.out.println("Population after 10 years "+a);
		System.out.println("Increase in population between 10 years "+(a-b));
		int per=((a-b)*100/b);
		System.out.println("Percentage of population increase in 10 years "+per);
		System.out.println("Percentage of population increase in a year "+per/10);
	}
}