import java.util.Scanner;
public class UserInterface {
	public static DiscountInfo generateBillAmount() {
	    return(Container containerobj)->
	    {   double dp=0;
	        if(containerobj.count>=100){
	        if(containerobj.volume==10)
	        dp=(20*containerobj.count)-(.1*containerobj.count*20);
	        else if(containerobj.volume==25)
	        dp=50*containerobj.count-(.15*containerobj.count*50);
	        }
	        else{
	        if(containerobj.volume==10)
	        dp=(containerobj.count*20);
	        else if(containerobj.volume==25)
	        dp= (containerobj.count*50);
	        }
	        return dp;
	   };
}
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name of the distributor");
		String s=sc.next();
		System.out.println("Enter the volume of the container(in litre)");
		int d=sc.nextInt();
		System.out.println("Enter the no of containers");
		int h=sc.nextInt();
		
		 if(d==25 || d==10)
		{
		Container obj=new Container(s,d,h);
		DiscountInfo k=generateBillAmount();
		double g=k.calculatePayableAmount (obj);
	    System.out.println("Generated Bill Amount");
		System.out.println("Distributor name: "+s);
        System.out.printf("Amount to be paid: Rs.%.2f",g);
		}
		else
		{
		    System.out.println("There is no Discount");
		}

	}
}
