public interface DiscountInfo {
	// Fill the code
	public double calculatePayableAmount (Container containerObj);
}
