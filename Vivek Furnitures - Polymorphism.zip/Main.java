import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Customer Name");
		String name=sc.nextLine();
		System.out.println("Enter Phone Number");
		long phone=sc.nextLong();
		sc.nextLine();
		System.out.println("Enter Address");
		String address=sc.nextLine();
		System.out.println("Enter Bero Type");
		String type=sc.nextLine();
		System.out.println("Enter Bero Colour");
		String colour=sc.nextLine();
		double price=0;
		Discount d=new Discount();
		Bero obj;
		if(type.equals("Steel Bero"))
		{
			System.out.println("Enter Bero Height");
			int height=sc.nextInt();
			sc.nextLine();
			obj=new SteelBero(type,colour,height);
			obj.calculatePrice();
			price=obj.getPrice()- d.calculateDiscount(obj);
		}
		else if(type.equals("Wooden Bero"))
		{
			System.out.println("Enter Wood Type");
			String wtype=sc.nextLine();
			obj=new WoodenBero(type,colour,wtype);
			obj.calculatePrice();
			price=obj.getPrice()- d.calculateDiscount(obj);
		}
		System.out.print("Amount needs to be paid Rs.");
		System.out.printf("%.2f",price);
	}

}
