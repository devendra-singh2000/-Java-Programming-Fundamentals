public class Discount {
	public double calculateDiscount(Bero bObj)
	{
		double price=bObj.getPrice();
		double discount=0;
		if(bObj instanceof SteelBero)
		{
			discount=price*0.1;
		}
		else if(bObj instanceof WoodenBero)
		{
			discount=price*0.15;
		}
		return discount;
	}
}

