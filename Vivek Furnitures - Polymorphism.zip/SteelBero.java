public class SteelBero extends Bero {
		private int beroHeight;

		public int getBeroHeight() {
			return beroHeight;
		}

		public void setBeroHeight(int beroHeight) {
			this.beroHeight = beroHeight;
		}
		
		public SteelBero(String type, String colour, int height) {
			// TODO Auto-generated constructor stub
			super(type, colour);
			this.beroHeight = height;
		}

		@Override
		public void calculatePrice() {
			int height=this.getBeroHeight();
			if(height==3)
			{
				this.setPrice(5000);
			}
			else if(height==5)
			{
				this.setPrice(8000);
			}
			else if(height==7)
			{
				this.setPrice(10000);
			}
		}
}

