import java.util.Scanner;
public class PrintMessage
{
public static void main (String[] args) {
    /* code */
    System.out.println("Welcome to Java world");
}
}