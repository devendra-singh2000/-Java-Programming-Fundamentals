import java.util.*;
import java.util.stream.*;
public class Main {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        ManagementUtility M=new ManagementUtility();
        Map<String,Integer> playerMap=new HashMap<String,Integer>();
        M.setPlayerMap(playerMap);
        int z=0;
        while(z!=3){
            System.out.println("Select an option:");
		    System.out.println("1.Add player score");
		    System.out.println("2.Display");
		    System.out.println("3.Exit");
		    z=sc.nextInt();
		    String name="";
		    int score=0;
		    if(z==1){
		        System.out.println("Enter the player name");
		        name=sc.next();
		        System.out.println("Enter the score");
		        score=sc.nextInt();
		        M.addPlayerScore(name,score);
		        
		    }
		    else if(z==2){
		        Map<String,Integer> playermap=M.getPlayerMap();
		        Stream<Map.Entry<String,Integer>> playerStream=playermap.entrySet().stream();
		        int max_score=M.maximumScore(playerStream);
		        if(max_score==0){
		            System.out.println("No players found");
		            
		        }
		        else{
		            System.out.println("The maximum score of an individual player for these match is "+max_score);
		            
		        }
		    }
		    else{
		        System.out.println("Thank you for using the application.");
		        break;
		    }
		    
		}
	}
}
