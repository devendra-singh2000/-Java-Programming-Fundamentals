import java.util.Map;
import java.util.*;
import java.util.stream.Stream;
import java.util.stream.Collectors;

public class ManagementUtility {
    private  Map<String,Integer> playerMap;
    public Map<String, Integer> getPlayerMap() {
        return playerMap;
        
    }

	public void setPlayerMap(Map<String, Integer> playerMap) {
		this.playerMap = playerMap;
	}

	public void addPlayerScore(String playerName,int score) {
	    Map<String, Integer> playerMap=getPlayerMap();
	    playerMap.put(playerName,score);
	    
	}
	
	public static int maximumScore(Stream<Map.Entry<String,Integer>> playerStream){
	    List<Integer> l=playerStream.map(Map.Entry::getValue).collect(Collectors.toList());
		if(l.isEmpty()){
		    return 0;
		    
		}
		else{
		    int m=Collections.max(l);
		    System.out.println(m);
		    return m;
		    
		}
	}

}
