import java.util.Scanner;
public class Main 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here 
		System.out.print("Applicant name\n");  
		String a = sc.nextLine();
		System.out.print("Marks obtained in HSC\n");  
		int b= sc.nextInt();
		System.out.print("Total possible marks in HSC \n");  
		int c= sc.nextInt();
		System.out.print("Engineering cutoff mark \n");  
		float d= sc.nextFloat();
		System.out.print("Marks obtained in SSLC \n");  
		int e= sc.nextInt();
		System.out.print("Total possible marks in SSLC \n");  
		int f= sc.nextInt();
		System.out.print("Gender \n");  
		char g= sc.next().charAt(0);
		System.out.print("Your Application has been Submitted Successfully \n");  
		System.out.println("The name of the applicant: "+a);
		System.out.print("Engineering Cutoff: "+d);
		System.out.print("\nApplicant gender: "+g);
		System.out.print("\nAll the best for your Career \n");
	}
}